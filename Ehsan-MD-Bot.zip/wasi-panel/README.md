# EHSAN MD BOT — Pairing Panel

This is the Ehsan Ali branded frontend for a WASI-MD V7 WhatsApp pairing panel.

## Deploy on Vercel
1. Upload this folder to a GitHub repository and import it into Vercel.
2. In Vercel Project Settings → Environment Variables, add `PAIRING_API_URL` with the URL of **your own trusted pairing backend**.
3. Redeploy after adding the variable.

The backend must accept a POST JSON body like `{"phone":"923001234567"}` and return JSON containing `code` or `error`. This ZIP does not include a WhatsApp bot session or pairing backend, so the panel will not generate a real pairing code until connected to a compatible backend. Never put session IDs, private tokens, or database credentials in frontend files.
